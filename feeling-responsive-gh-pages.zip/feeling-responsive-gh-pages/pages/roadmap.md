---
layout              : page
title               : "Roadmap – What's up next?!?"
subheadline         : "ToDo-List &amp; Ideas"
teaser              : "<em>Feeling Responsive</em> works fine. I am happy lots of people use it. Currently I have no plans to make it <em>better</em> or <em>worse</em>."
header:
   image_fullwidth  : "header_roadmap_3.jpg"
permalink           : "/roadmap/"
---

